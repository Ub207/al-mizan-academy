# 🕌 Al-Mizan Quran Academy — AI Chatbot

An AI-powered student assistant for **Al-Mizan Online Quran Academy** built with **RAG (Retrieval-Augmented Generation)** using Streamlit, Groq API, FAISS, and Sentence Transformers.

![Python](https://img.shields.io/badge/Python-3.10+-blue)
![Streamlit](https://img.shields.io/badge/Streamlit-1.45-red)
![Groq](https://img.shields.io/badge/Groq-LLaMA_3.3-green)
![RAG](https://img.shields.io/badge/RAG-FAISS-orange)

## ✨ Features

- 🤖 **RAG-Powered Answers** — Retrieves accurate information from the academy's knowledge base
- 🕌 **Islamic-Themed UI** — Beautiful dark theme with gold accents and Arabic calligraphy
- 💬 **Conversational Memory** — Maintains chat context across the conversation
- ⚡ **Fast Responses** — Powered by Groq's ultra-fast LLaMA 3.3 70B inference
- 📱 **Responsive Design** — Works on desktop and mobile
- 🎯 **Quick Questions** — Pre-built buttons for common student queries

## 🏗️ Architecture

```
User Query → Sentence Transformer Embedding → FAISS Similarity Search
    → Top 3 Relevant Chunks → Groq LLaMA 3.3 → Contextual Response
```

## 🚀 Quick Start

### 1. Clone the repo
```bash
git clone https://github.com/Ub207/quran-academy-chatbot.git
cd quran-academy-chatbot
```

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. Set your Groq API key
```bash
# Option A: Environment variable
export GROQ_API_KEY="your-key-here"

# Option B: Streamlit secrets
# Edit .streamlit/secrets.toml
```

Get a free API key at [console.groq.com](https://console.groq.com)

### 4. Run the app
```bash
streamlit run app.py
```

## 📁 Project Structure

```
quran-academy-chatbot/
├── app.py                    # Main Streamlit application
├── quran_academy_kb.txt      # Knowledge base (FAQ content)
├── requirements.txt          # Python dependencies
├── .streamlit/
│   └── secrets.toml          # API keys (not committed)
└── README.md
```

## 🌐 Deploy to Streamlit Cloud (Free)

1. Push this repo to GitHub
2. Go to [share.streamlit.io](https://share.streamlit.io)
3. Connect your GitHub repo
4. Add `GROQ_API_KEY` in Streamlit Cloud Secrets
5. Deploy! 🚀

## 🛠️ Tech Stack

| Technology | Purpose |
|---|---|
| **Streamlit** | Web UI framework |
| **Groq API** | LLM inference (LLaMA 3.3 70B) |
| **FAISS** | Vector similarity search |
| **Sentence Transformers** | Text embeddings (all-MiniLM-L6-v2) |
| **LangChain** | Text splitting utilities |

## 📚 About Al-Mizan Academy

Al-Mizan Online Quran Academy offers personalized one-on-one Quran classes worldwide, specializing in:
- Tajweed (Proper Recitation)
- Hifz-ul-Quran (Memorization)
- Saba Qiraat (Seven Recitation Styles)
- Ijazah Program (Certification)

🌐 [Visit Website](https://quranconnectacademy.netlify.app) | ✉️ usmanubaidurrehman@gmail.com

## 👨‍💻 Author

**Ubaid ur Rehman** — Qari, Aalim, Saba Qiraat Specialist & AI Developer
- 🔗 [GitHub](https://github.com/Ub207)
- 🔗 [LinkedIn](https://linkedin.com/in/ubaidurrehman)

## 📄 License

MIT License — Feel free to use and modify for your own academy or Islamic project.

---

*Built with ❤️ for the Muslim Ummah*
